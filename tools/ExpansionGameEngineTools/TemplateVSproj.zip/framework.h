#pragma once

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN             // Exclure les en-têtes Windows rarement utilisés
// Fichiers d'en-tête Windows

#include <windows.h>
#endif